
function subir(){
        var formData = new FormData(document.getElementById("add_ficheros"));
        var url = 'http://'+window.location.host+'/index.php/Main/importar_fichero';
        jQuery.ajax({
          url:url,
          type:"post",
          data:formData,
          dataType: "json",
          cache: false,
          contentType: false,
          processData: false,
             success: function(datos){
                 if (datos.correcto) {
                   var ctx1 = document.getElementById('myChart1').getContext('2d');
                   var chart = new Chart(ctx1, {
                       type: 'line',
                       data: {
                           labels: datos.tiempos,
                           datasets: [{
                               label: 'Temperature Flue Gases Source (ºC)',
                               backgroundColor: 'grey',
                               borderColor: 'grey',
                               data: datos.TemperatureFlueGas,
                               fill:false
                           },
                           {
                               label: 'Temperature Air (ºC)',
                               backgroundColor: 'blue',
                               borderColor: 'blue',
                               data: datos.TemperatureAir,
                               fill:false
                           },
                           {
                               label: 'Temperature Recirculation (ºC)',
                               backgroundColor: 'orange',
                               borderColor: 'orange',
                               data: datos.TemperatureRecirculation,
                               fill:false
                           },
                           {
                               label: 'Temperature Product (ºC)',
                               backgroundColor: 'green',
                               borderColor: 'green',
                               data: datos.TemperatureWood,
                               fill:false
                           }

                   		]},
                       options: {
    legend: {position: 'bottom'},
    scales: {
            xAxes: [{
                    afterTickToLabelConversion: function(data){
                        var xLabels = data.ticks;

                        xLabels.forEach(function (labels, i) {
                            if (i % 10 != 0){
                                xLabels[i] = '';
                            }
                        });
                    },
                    scaleLabel: {
                      display: true,
                      labelString: 'Time [sec]'
                    }
                }],
              yAxes:[
                {scaleLabel:{
                  display: true,
                  labelString: 'Temperature[ºC]'
                },
		ticks:{
			beginAtZero: true,
			max:800			
			}
              }]

        }
  }
                   });
                   ctx1 = document.getElementById('myChart2').getContext('2d');
                   chart = new Chart(ctx1, {
                       type: 'line',
                       data: {
                           labels: datos.tiempos,
                           datasets: [{
                               label: 'Mass Flow Flue Gases Source (kg/s)',
                               backgroundColor: 'grey',
                               borderColor: 'grey',
                               data: datos.MassFlueGas,
                               fill:false
                           },
                           {
                               label: 'Mass Air (kg/s)',
                               backgroundColor: 'blue',
                               borderColor: 'blue',
                               data: datos.MassAir,
                               fill:false
                           },
                           {
                               label: 'Mass Recirculation (kg/s)',
                               backgroundColor: 'orange',
                               borderColor: 'orange',
                               data: datos.MassRecirculation,
                               fill:false
                           }



                   		]},
                       options: {
    legend: {position: 'bottom'},
    scales: {
            xAxes: [{
                afterTickToLabelConversion: function(data){


                    var xLabels = data.ticks;

                    xLabels.forEach(function (labels, i) {
                        if (i % 10 != 0){
                            xLabels[i] = '';
                        }
                    });
                },
                scaleLabel: {
                  display: true,
                  labelString: 'Time [sec]'
                }
            }],
          yAxes:[
            {scaleLabel:{
              display: true,
              labelString: 'Mass Flow [kg/s]'
            },
		ticks:{
			beginAtZero: true,
			max:50			
			}
          }]
        }
  }
                   });
                   ctx1 = document.getElementById('myChart3').getContext('2d');
                   chart = new Chart(ctx1, {
                       type: 'line',
                       data: {
                            labels: datos.tiempos,
                           datasets: [{
                               label: 'VFFeed (%)',
                               backgroundColor: 'black',
                               borderColor: 'black',
                               fill:false,
                               data: datos.VFFeed
                           }
                   		,{
                               label: 'VFRotaryDryer (%)',
                               backgroundColor: 'green',
                               borderColor: 'green',
                               data: datos.VFRotaryDryer,
                               fill:false
                           }

                   		]},
                       options: {
    legend: {position: 'bottom'},
    scales: {
            xAxes: [{
                afterTickToLabelConversion: function(data){


                    var xLabels = data.ticks;

                    xLabels.forEach(function (labels, i) {
                        if (i % 10 != 0){
                            xLabels[i] = '';
                        }
                    });
                },
                scaleLabel: {
                  display: true,
                  labelString: 'Time [sec]'
                }
            }],
          yAxes:[
            {scaleLabel:{
              display: true,
              labelString: 'Actuator speed[%]'
            },
		ticks:{
			beginAtZero: true,
			max:100			
			}
          }]
        }
  }
                   });
                   document.getElementById("block-two").style.display="none";
                   document.getElementById("block-three").style.display="flex";
                   document.getElementById("menu1").className = "";
                   document.getElementById("menu2").className = "green";

                 }else{
                   alert(datos.mensaje);
                 }

               }

          });
	  document.getElementById("resultados").style.backgroundColor = "";
          return false;
    }
function preguntar() {
  document.getElementById("preguntarMoal").style.display = "block";
}
function cancelar() {
  document.getElementById("preguntarMoal").style.display = "none";
}
function enviar() {
var sd=0;
var combustiongas=0;
var reciculation=0;

var collection = document.getElementsByClassName("sd");

for (let i = 0; i < collection.length; i++) {
  sd= Math.round((sd + parseFloat(collection[i].value))* 100) / 100;
}

collection = document.getElementsByClassName("combustiongas");

for (let i = 0; i < collection.length; i++) {
  combustiongas= Math.round((combustiongas + parseFloat(collection[i].value))* 100) / 100;
}

//collection = document.getElementsByClassName("recirculation");

//for (let i = 0; i < collection.length; i++) {
//  recirculation= Math.round((recirculation + parseFloat(collection[i].value))* 100) / 100;
//}


if(sd!=100 || combustiongas!=100){
 alert("The sum of size distribution and combustion gas mass fraction should be 100. Please check variables.");

}else{

document.getElementById("resultados").style.backgroundColor = "";
document.getElementById("preguntarMoal").style.display = "none";
document.getElementById("envioIncorrecto").style.display = "none";
document.getElementById("envioCorrecto").style.display = "none";
document.getElementById("procesandoModal").style.display = "block";

document.getElementById('startTime').value=document.getElementById('startTimeInicial').value;
  document.getElementById('endTime').value=document.getElementById('endTimeInicial').value;
  var formData = new FormData(document.getElementById("datos"));
  var url = 'http://'+window.location.host+'/index.php/Main/result';

  jQuery.ajax({
    url:url,
    type:"post",
    data:formData,
    dataType: "json",
    cache: false,
    contentType: false,
    processData: false,
       success: function(datos){
         if (datos.correcto) {


         var datasets=[];
         var dataset;
         for (let i = 0; i < datos.TemperaturesGas.length; i++) {
            dataset={
                label: datos.TemperaturesGas[i],
                backgroundColor: datos.colores[i],
                borderColor: datos.colores[i],
                data: datos.valores[datos.TemperaturesGas[i]],
                fill:false
            }
            datasets.push(dataset);
         }
         var ctx1 = document.getElementById('TemperaturesGas').getContext('2d');

         var chart = new Chart(ctx1, {
             type: 'line',
             data: {
                 labels: datos.tiempos,
                 datasets: datasets,
             },
             options: {
legend: {position: 'bottom'},
scales: {
  xAxes: [{
          afterTickToLabelConversion: function(data){


              var xLabels = data.ticks;

              xLabels.forEach(function (labels, i) {
                  if (i % 10 != 0){
                      xLabels[i] = '';
                  }
              });
          },
          scaleLabel: {
            display: true,
            labelString: 'Time [sec]'
          }
      }],
    yAxes:[
      {scaleLabel:{
        display: true,
        labelString: 'Temperature [ºC]'
      },
		ticks:{
			beginAtZero: true,
			max:800			
			}
    }]

}
}
         });
         datasets=[];
         for (let i = 0; i < datos.TemperaturesParticles.length; i++) {
            dataset={
                label: datos.TemperaturesParticles[i],
                backgroundColor: datos.colores[i],
                borderColor: datos.colores[i],
                data: datos.valores[datos.TemperaturesParticles[i]],
                fill:false
            }
            datasets.push(dataset);
         }
         ctx1 = document.getElementById('TemperaturesParticles').getContext('2d');
         chart = new Chart(ctx1, {
             type: 'line',
             data: {
                 labels: datos.tiempos,
                 datasets: datasets,
             },
             options: {
         legend: {position: 'bottom'},
         scales: {
         xAxes: [{
          afterTickToLabelConversion: function(data){


              var xLabels = data.ticks;

              xLabels.forEach(function (labels, i) {
                  if (i % 10 != 0){
                      xLabels[i] = '';
                  }
              });
          },
          scaleLabel: {
            display: true,
            labelString: 'Time [sec]'
          }
         }],
         yAxes:[
         {scaleLabel:{
         display: true,
         labelString: 'Temperature [ºC]'
         },
		ticks:{
			beginAtZero: true,
			max:200			
			}
         }]

         }
         }
         });
         datasets=[];
         for (let i = 0; i < datos.MassFlows.length; i++) {
            dataset={
                label: datos.MassFlows[i],
                backgroundColor: datos.colores[i],
                borderColor: datos.colores[i],
                data: datos.valores[datos.MassFlows[i]],
                fill:false
            }
            datasets.push(dataset);
         }
         ctx1 = document.getElementById('MassFlows').getContext('2d');
         chart = new Chart(ctx1, {
             type: 'line',
             data: {
                 labels: datos.tiempos,
                 datasets: datasets,
             },
             options: {
         legend: {position: 'bottom'},
         scales: {
         xAxes: [{
          afterTickToLabelConversion: function(data){


              var xLabels = data.ticks;

              xLabels.forEach(function (labels, i) {
                  if (i % 10 != 0){
                      xLabels[i] = '';
                  }
              });
          },
          scaleLabel: {
            display: true,
            labelString: 'Time [sec]'
          }
         }],
         yAxes:[
         {scaleLabel:{
         display: true,
         labelString: 'Mass Flow [t/h]'
         },
		ticks:{
			beginAtZero: true,
			max:100			
			}
         }]

         }
         }
         });
         datasets=[];
         for (let i = 0; i < datos.EvapRate.length; i++) {
            dataset={
                label: datos.EvapRate[i],
                backgroundColor: datos.colores[i],
                borderColor: datos.colores[i],
                data: datos.valores[datos.EvapRate[i]],
                fill:false
            }
            datasets.push(dataset);
         }
         ctx1 = document.getElementById('EvapRate').getContext('2d');
         chart = new Chart(ctx1, {
             type: 'line',
             data: {
                 labels: datos.tiempos,
                 datasets: datasets,
             },
             options: {
         legend: {position: 'bottom'},
         scales: {
         xAxes: [{
          afterTickToLabelConversion: function(data){


              var xLabels = data.ticks;

              xLabels.forEach(function (labels, i) {
                  if (i % 10 != 0){
                      xLabels[i] = '';
                  }
              });
          },
          scaleLabel: {
            display: true,
            labelString: 'Time [sec]'
          }
         }],
         yAxes:[
         {scaleLabel:{
         display: true,
         labelString: 'Evaporation Rate [kgH2O/s]'
         }
         }]

         }
         }
         });
         datasets=[];
         for (let i = 0; i < datos.Humidity.length; i++) {
            dataset={
                label: datos.Humidity[i],
                backgroundColor: datos.colores[i],
                borderColor: datos.colores[i],
                data: datos.valores[datos.Humidity[i]],
                fill:false
            }
            datasets.push(dataset);
         }
         ctx1 = document.getElementById('Humidity').getContext('2d');
         chart = new Chart(ctx1, {
             type: 'line',
             data: {
                 labels: datos.tiempos,
                 datasets: datasets,
             },
             options: {
         legend: {position: 'bottom'},
         scales: {
         xAxes: [{
          afterTickToLabelConversion: function(data){


              var xLabels = data.ticks;

              xLabels.forEach(function (labels, i) {
                  if (i % 10 != 0){
                      xLabels[i] = '';
                  }
              });
          },
          scaleLabel: {
            display: true,
            labelString: 'Time [sec]'
          }
         }],
         yAxes:[
         {scaleLabel:{
         display: true,
         labelString: 'Humidity [%]'
         },
		ticks:{
			beginAtZero: true,
			max:60			
			}
         }]

         }
         }
         });
         datasets=[];
         for (let i = 0; i < datos.Balances.length; i++) {
            dataset={
                label: datos.Balances[i],
                backgroundColor: datos.colores[i],
                borderColor: datos.colores[i],
                data: datos.valores[datos.Balances[i]],
                fill:false
            }
            datasets.push(dataset);
         }
         ctx1 = document.getElementById('Balances').getContext('2d');
         chart = new Chart(ctx1, {
             type: 'line',
             data: {
                 labels: datos.tiempos,
                 datasets: datasets,
             },
             options: {
         legend: {position: 'bottom'},
         scales: {
         xAxes: [{
          afterTickToLabelConversion: function(data){


              var xLabels = data.ticks;

              xLabels.forEach(function (labels, i) {
                  if (i % 10 != 0){
                      xLabels[i] = '';
                  }
              });
          },
          scaleLabel: {
            display: true,
            labelString: 'Time [sec]'
          }
         }],
         yAxes:[
         {scaleLabel:{
         display: true,
         labelString: 'Balances [kJ/kg]'
         }
         }]

         }
         }
         });

         datasets=[];
         for (let i = 0; i < datos.derLargeParticles.length; i++) {
            dataset={
                label: datos.derLargeParticles[i],
                backgroundColor: datos.colores[i],
                borderColor: datos.colores[i],
                data: datos.valores[datos.derLargeParticles[i]],
                fill:false
            }
            datasets.push(dataset);
         }
         ctx1 = document.getElementById('derLargeParticles').getContext('2d');
         chart = new Chart(ctx1, {
             type: 'line',
             data: {
                 labels: datos.tiempos,
                 datasets: datasets,
             },
             options: {
         legend: {position: 'bottom'},
         scales: {
         xAxes: [{
          afterTickToLabelConversion: function(data){


              var xLabels = data.ticks;

              xLabels.forEach(function (labels, i) {
                  if (i % 10 != 0){
                      xLabels[i] = '';
                  }
              });
          },
          scaleLabel: {
            display: true,
            labelString: 'Time [sec]'
          }
         }],
         yAxes:[
         {scaleLabel:{
         display: true,
         labelString: 'BalanceParticles [-]'
         }
         }]

         }
         }
         });

         datasets=[];
         for (let i = 0; i < datos.VolumetricFlowRate.length; i++) {
            dataset={
                label: datos.VolumetricFlowRate[i],
                backgroundColor: datos.colores[i],
                borderColor: datos.colores[i],
                data: datos.valores[datos.VolumetricFlowRate[i]],
                fill:false
            }
            datasets.push(dataset);
         }
         ctx1 = document.getElementById('VolumetricFlowRate').getContext('2d');
         chart = new Chart(ctx1, {
             type: 'line',
             data: {
                 labels: datos.tiempos,
                 datasets: datasets,
             },
             options: {
         legend: {position: 'bottom'},
         scales: {
         xAxes: [{
          afterTickToLabelConversion: function(data){


              var xLabels = data.ticks;

              xLabels.forEach(function (labels, i) {
                  if (i % 10 != 0){
                      xLabels[i] = '';
                  }
              });
          },
          scaleLabel: {
            display: true,
            labelString: 'Time [sec]'
          }
         }],
         yAxes:[
         {scaleLabel:{
         display: true,
         labelString: 'Volumetric Flow Rate [m3/h]'
         },
		ticks:{
			beginAtZero: true,
			max:100000			
			}
         }]

         }
         }
         });

         document.getElementById("resultados").disabled = false;
         document.getElementById("envioIncorrecto").style.display = "none";
         document.getElementById("envioCorrecto").style.display = "block";
         document.getElementById("resultados").style.backgroundColor = "var(--green)";
         document.getElementById('descargar').href=datos.archivo;
         var html='<h2 class="title">Summary Results</h2>';
         for (let i = 0; i < datos.resumenes.length; i++) {

            html = html +'<ul><li><div> <label for="temperature-ambient">'+datos.titulos[i]+'</label><input  type="number" value="'+ Math.round(parseFloat(datos.valores[datos.resumenes[i]][datos.valores[datos.resumenes[i]].length - 1])*100)/100+'" disabled><p>'+datos.medidas[i]+'</p></div></li></ul>';
            document.getElementById('resumen').innerHTML=html;
         }
         }else{
            document.getElementById("resultados").disabled = true;
            document.getElementById("envioIncorrecto").style.display = "block";
            document.getElementById("envioCorrecto").style.display = "none";
            document.getElementById('texto').innerHTML=datos.mensaje;
            document.getElementById('myModal').style.display = "block";
         }
	document.getElementById("procesandoModal").style.display = "none";
       },
    error: function(XMLHttpRequest, textStatus, errorThrown) { 
        alert("Unexpected error. Please check the configuration. Results cannot be obtained"); 
       document.getElementById("procesandoModal").style.display = "none";
    }

     });
 }
    return false;
}
function mostrarResultados(){
  document.getElementById("block").style.display="none";
  document.getElementById("block-three").style.display="none";
  document.getElementById("block-four").style.display="flex";
  document.getElementById("menu2").className = "";
  document.getElementById("menu3").className = "green";
}
function volver1() {
  document.getElementById("block").style.display="block";
  document.getElementById("block-two").style.display="block";
  document.getElementById("block-three").style.display="none";
  document.getElementById("block-four").style.display="none";
  document.getElementById("menu1").className = "green";
  document.getElementById("menu2").className = "";
  document.getElementById("menu3").className = "";
}
function cerrarModal() {
	var modal = document.getElementById("myModal");
  modal.style.display = "none";
}
function abrirInformacion() {
  document.getElementById("informacion").style.display = "block";
}
function cerrarInformacion() {
  document.getElementById("informacion").style.display = "none";
}
function graficas() {
document.getElementById("procesandoGrathic").style.display = "block";
	var reportPageHeight = 2000;
  var reportPageWidth = 1000;

  // create a new canvas object that we will populate with all other canvas objects
  var pdfCanvas = $('<canvas />').attr({
    id: "canvaspdf",
    width: 1000,
    height: reportPageHeight
  });

  // keep track canvas position
  var pdfctx = $(pdfCanvas)[0].getContext('2d');
  var pdfctxX = 20;
  var pdfctxY = 50;
  var buffer = 100;
 //var pdf =  new jsPDF();
 var pdf =  new jsPDF('l', 'pt','a4');
  // for each chart.js chart
  $("canvas").each(function(index) {
		if(index>2){
			// get the chart height/width
	    var canvasHeight = $(this).innerHeight();
	    var canvasWidth = $(this).innerWidth()-400;
	    // draw the chart into the new canvas
	    pdfctx.drawImage($(this)[0], pdfctxX, pdfctxY, canvasWidth, canvasHeight);
			pdfctxX=0;
			pdfctxY=pdfctxY+50+canvasHeight;
				pdf.addImage($(pdfCanvas)[0], 'PNG', 0, 0);
				if(index!=10){
					pdf.addPage();
				}

		    pdfctxX = 20;
		    pdfctxY = 50;
		    pdfCanvas = $('<canvas />').attr({
		      id: "canvaspdf",
		      width: 1000,
		      height: reportPageHeight
		    });
		    pdfctx = $(pdfCanvas)[0].getContext('2d');

		}

  });

  // create new pdf and add our new canvas as an image

  // download the pdf
	var hoy = new Date();
	var fecha = hoy.getDate() + '-' + ( hoy.getMonth() + 1 ) + '-' + hoy.getFullYear();
  var hora = hoy.getHours() + '-' + hoy.getMinutes();
  pdf.save('graficas_'+fecha+'_'+hora+'.pdf');
document.getElementById("procesandoGrathic").style.display = "none";
}