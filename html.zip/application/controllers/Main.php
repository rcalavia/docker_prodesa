<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Main extends CI_Controller {
		 //functions
		 public $temporal=FCPATH.'application/files/temporal/';
		 public $model='/home/model/';
		 public $entrada='/home/input/';
		 public $salida='/home/output/';
		 /*public $model=FCPATH.'application/files/model/';
		 public $entrada=FCPATH.'application/files/input/';
		 public $salida=FCPATH.'application/files/output/';*/

		 function index()
		 {
			  if($this->session->has_userdata('user')){
			  error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
				$this->load->view('main_view');
			}else{
			redirect('http://'.$_SERVER["HTTP_HOST"].'/index.php/Login');
			}
		 }
		 public function importar_fichero()
		 {
			 error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
			 $directorio = FCPATH.'application/files/';
 $destino=$this->temporal;
   $respuesta=array();
 $name=basename($_FILES['subir_archivo']['name']);
 $subir_archivo = $directorio.$name;
 $respuesta=array();
 if ($name=="Time_series_inputs.xlsx") {
	 if (move_uploaded_file($_FILES['subir_archivo']['tmp_name'], $subir_archivo)) {
     if (!file_exists($destino)) {
       mkdir($destino, 0777, true);
     }
     rename($subir_archivo,$destino.$name);
  	 $respuesta=$this->lecturaexcel();
  	 //contamos cuantas fotografías tenemos cargadas en la carpeta
  	 $respuesta["cuantos"]=count(scandir($destino)) - 2;
     $respuesta["correcto"]=true;

   }else{
     $respuesta["correcto"]=false;
		 $respuesta["mensaje"]="No se a podido subir el archivo vuelva a intentarlo";
   }
}else{
	$respuesta["correcto"]=false;
	$respuesta["mensaje"]="El archivo debe llamarse Time_series_inputs.xlsx";
}

 echo json_encode($respuesta);
		 }
		 public function result()
		 {
			set_time_limit(6000);
			 error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
			 $id=count(scandir($this->temporal))-2;
		 	$valores=array();
			$datos=array();
/*			$opciones=" hola T_particula_amb P_atm relative_humidity_param feedScrew1_Density, rho_s init_hum d_p[1] d_p[2] d_p[3] d_p[4] d_p[5] size_dist[1] size_dist[2] size_dist[3] size_dist[4] size_dist[5] H2O_ini CO2_ini N2_ini O2_ini H2O_air CO2_air N2_air O2_air H2O_recirc CO2_recirc N2_recirc O2_recirc D_dryer L hopper_Diameter hopper_Height DF DS P RPM_Max Hz_Max Filling
 ";*/
			$opciones=" hola rho_s Density NominalSpeed n_sects n_types sections_type[1] sections_type[2] sections_type[3] sections_type[4] sections_type[5] sections_type[6] sections_type[7] sections_type[8] sections_type[9] sections_type[10] len_by_type_array[1] len_by_type_array[2] len_by_type_array[3] len_by_type_array[4] len_by_type_array[5] blade_by_type_array[1] blade_by_type_array[2] blade_by_type_array[3] blade_by_type_array[4] blade_by_type_array[5] factor_by_type_array[1] factor_by_type_array[2] factor_by_type_array[3] factor_by_type_array[4] factor_by_type_array[5] T_particula_amb P_atm relative_humidity_param feedScrew1_Density, rho_s init_hum d_p[1] d_p[2] d_p[3] d_p[4] d_p[5] size_dist[1] size_dist[2] size_dist[3] size_dist[4] size_dist[5] H2O_ini CO2_ini N2_ini O2_ini H2O_1 CO2_1 N2_1 O2_1 D_dryer L hopper_Diameter hopper_Height DF DS P RPM_Max Hz_Max Filling
 ";

			$valores["T_particula_amb"]=floatval($this->input->post('T_particula_amb', TRUE));
			if($valores["T_particula_amb"]>0){
				$valores["T_particula_amb"]=$valores["T_particula_amb"];
			}


			$valores["relative_humidity_param"]=floatval($this->input->post('relative_humidity_param', TRUE));
			if($valores["relative_humidity_param"]>0){
				$valores["relative_humidity_param"]=$valores["relative_humidity_param"]/100;//Pasar a tanto por 1
			}

			$valores["P_atm"]=floatval($this->input->post('P_atm', TRUE));

			//$valores["sourceMassFlowSolid_solid_T"]=floatval($this->input->post('sourceMassFlowSolid.solid.T', TRUE));
			//$valores["feedScrew1.Density"]=floatval($this->input->post('feedScrew1.Density', TRUE));
			$valores["rho_s"]=floatval($this->input->post('rho_s', TRUE));
			

			$valores["init_hum"]=floatval($this->input->post('init_hum', TRUE));
			if($valores["init_hum"]>0){
				$valores["init_hum"]=$valores["init_hum"]/100;//Pasar a tanto por 1
			}
			

			$valores["d_p[1]"]=floatval($this->input->post('d_p[1]', TRUE));
			$valores["d_p[2]"]=floatval($this->input->post('d_p[2]', TRUE));
			$valores["d_p[3]"]=floatval($this->input->post('d_p[3]', TRUE));
			$valores["d_p[4]"]=floatval($this->input->post('d_p[4]', TRUE));
			$valores["d_p[5]"]=floatval($this->input->post('d_p[5]', TRUE));
			
			if($valores["d_p[1]"]>0){
				$valores["d_p[1]"]=$valores["d_p[1]"]/1000;//Pasar a m
			}
			if($valores["d_p[2]"]>0){
				$valores["d_p[2]"]=$valores["d_p[2]"]/1000;//Pasar a m
			}
			if($valores["d_p[3]"]>0){
				$valores["d_p[3]"]=$valores["d_p[3]"]/1000;//Pasar a m
			}
			if($valores["d_p[4]"]>0){
				$valores["d_p[4]"]=$valores["d_p[4]"]/1000;//Pasar a m
			}
			if($valores["d_p[1]"]>0){
				$valores["d_p[5]"]=$valores["d_p[5]"]/1000;//Pasar a m
			}


			$valores["size_dist[1]"]=floatval($this->input->post('size_dist[1]', TRUE));
			$valores["size_dist[2]"]=floatval($this->input->post('size_dist[2]', TRUE));
			$valores["size_dist[3]"]=floatval($this->input->post('size_dist[3]', TRUE));
			$valores["size_dist[4]"]=floatval($this->input->post('size_dist[4]', TRUE));
			$valores["size_dist[5]"]=floatval($this->input->post('size_dist[5]', TRUE));
			if($valores["size_dist[1]"]>0){
				$valores["size_dist[1]"]=$valores["size_dist[1]"]/100;//Pasar a tanto por 1
			}
			if($valores["size_dist[2]"]>0){
				$valores["size_dist[2]"]=$valores["size_dist[2]"]/100;//Pasar a tanto por 1
			}
			if($valores["size_dist[3]"]>0){
				$valores["size_dist[3]"]=$valores["size_dist[3]"]/100;//Pasar a tanto por 1
			}
			if($valores["size_dist[4]"]>0){
				$valores["size_dist[4]"]=$valores["size_dist[4]"]/100;//Pasar a tanto por 1
			}
			if($valores["size_dist[1]"]>0){
				$valores["size_dist[5]"]=$valores["size_dist[5]"]/100;//Pasar a tanto por 1
			}


			$valores["H2O_ini"]=floatval($this->input->post('H2O_ini', TRUE));
			$valores["CO2_ini"]=floatval($this->input->post('CO2_ini', TRUE));
			$valores["N2_ini"]=floatval($this->input->post('N2_ini', TRUE));
			$valores["O2_ini"]=floatval($this->input->post('O2_ini', TRUE));
			$valores["H2O_1"]=floatval($this->input->post('H2O_1', TRUE));
			$valores["CO2_1"]=floatval($this->input->post('CO2_1', TRUE));
			$valores["N2_1"]=floatval($this->input->post('N2_1', TRUE));
			$valores["O2_1"]=floatval($this->input->post('O2_1', TRUE));
			$valores["D_dryer"]=floatval($this->input->post('D_dryer', TRUE));
			$valores["L"]=floatval($this->input->post('L', TRUE));
			$valores["hopper_Diameter"]=floatval($this->input->post('hopper_Diameter', TRUE));
			$valores["hopper_Height"]=floatval($this->input->post('hopper_Height', TRUE));
			$valores["DF"]=floatval($this->input->post('Df', TRUE));
			$valores["DS"]=floatval($this->input->post('Ds', TRUE));
			$valores["Pitch"]=floatval($this->input->post('Pitch', TRUE));
			$valores["RPM_Max"]=floatval($this->input->post('RPM_Max', TRUE));
			$valores["Hz_Max"]=floatval($this->input->post('Hz_Max', TRUE));
			$valores["Filling"]=floatval($this->input->post('Filling', TRUE));
			$valores["startTime"]=intval($this->input->post('startTime', TRUE));
			$valores["endTime"]=intval($this->input->post('endTime', TRUE));
			
			$valores["n_sects"]=intval($this->input->post('n_sects', TRUE));
			$valores["n_types"]=intval($this->input->post('n_types', TRUE));
			$valores["sections_type[1]"]=intval($this->input->post('sections_type[1]', TRUE));
			$valores["sections_type[2]"]=intval($this->input->post('sections_type[2]', TRUE));
			$valores["sections_type[3]"]=intval($this->input->post('sections_type[3]', TRUE));
			$valores["sections_type[4]"]=intval($this->input->post('sections_type[4]', TRUE));
			$valores["sections_type[5]"]=intval($this->input->post('sections_type[5]', TRUE));
			$valores["sections_type[6]"]=intval($this->input->post('sections_type[6]', TRUE));
			$valores["sections_type[7]"]=intval($this->input->post('sections_type[7]', TRUE));
			$valores["sections_type[8]"]=intval($this->input->post('sections_type[8]', TRUE));
			$valores["sections_type[9]"]=intval($this->input->post('sections_type[9]', TRUE));
			$valores["sections_type[10]"]=intval($this->input->post('sections_type[10]', TRUE));
			$valores["len_by_type_array[1]"]=floatval($this->input->post('len_by_type_array[1]', TRUE));
			$valores["len_by_type_array[2]"]=floatval($this->input->post('len_by_type_array[2]', TRUE));
			$valores["len_by_type_array[3]"]=floatval($this->input->post('len_by_type_array[3]', TRUE));
			$valores["len_by_type_array[4]"]=floatval($this->input->post('len_by_type_array[4]', TRUE));
			$valores["len_by_type_array[5]"]=floatval($this->input->post('len_by_type_array[5]', TRUE));
			$valores["factor_by_type_array[1]"]=floatval($this->input->post('factor_by_type_array[1]', TRUE));
			$valores["factor_by_type_array[2]"]=floatval($this->input->post('factor_by_type_array[2]', TRUE));
			$valores["factor_by_type_array[3]"]=floatval($this->input->post('factor_by_type_array[3]', TRUE));
			$valores["factor_by_type_array[4]"]=floatval($this->input->post('factor_by_type_array[4]', TRUE));
			$valores["factor_by_type_array[5]"]=floatval($this->input->post('factor_by_type_array[5]', TRUE));
			$valores["Density"]=floatval($this->input->post('Density', TRUE));
			$valores["NominalSpeed"]=floatval($this->input->post('NominalSpeed', TRUE));			

			$this->modificar("ModelPruebaParticulas",$valores,$opciones,$id);
			$this->lecturaexcel_txt($id);
			if (file_exists(FCPATH.'application/files/Time_series_inputs.xlsx')) {
				unlink(FCPATH.'application/files/Time_series_inputs.xlsx');
			}
			$datos["Tº"]=$valores["T_particula_amb"];
$datos["Press."]=$valores["P_atm"];
$datos["Rel. Humidity"]=$valores["relative_humidity_param"];
$datos["Density particle"]=$valores["rho_s"];
$datos["Rel. WET Humidity"]=$valores["init_hum"];
$datos["Diameter Particle [1]"]=$valores["d_p[1]"];
$datos["Diameter Particle [2]"]=$valores["d_p[2]"];
$datos["Diameter Particle [3]"]=$valores["d_p[3]"];
$datos["Diameter Particle [4]"]=$valores["d_p[4]"];
$datos["Diameter Particle [5]"]=$valores["d_p[5]"];
$datos["Particle Distribution [1]"]=$valores["size_dist[1]"];
$datos["Particle Distribution [2]"]=$valores["size_dist[2]"];
$datos["Particle Distribution [3]"]=$valores["size_dist[3]"];
$datos["Particle Distribution [4]"]=$valores["size_dist[4]"];
$datos["Particle Distribution [5]"]=$valores["size_dist[5]"];
$datos["H2O_ROTARYDRYER"]=$valores["H2O_ini"];
$datos["CO2_ROTARYDRYER"]=$valores["CO2_ini"];
$datos["N2_ROTARYDRYER"]=$valores["N2_ini"];
$datos["O2_ROTARYDRYER"]=$valores["O2_ini"];
$datos["H2O_RECIRCULATION"]=$valores["H2O_1"];
$datos["CO2_RECIRCULATION"]=$valores["CO2_1"];
$datos["N2_RECIRCULATION"]=$valores["N2_1"];
$datos["O2_RECIRCULATION"]=$valores["O2_1"];
$datos["Diameter (m)"]=$valores["D_dryer"];
$datos["Length (m)"]=$valores["L"];
$datos["Diameter"]=$valores["hopper_Diameter"];
$datos["Height"]=$valores["hopper_Height"];
$datos["DF"]=$valores["DF"];
$datos["DS"]=$valores["DS"];
$datos["P"]=$valores["Pitch"];
$datos["RPM Max"]=$valores["RPM_Max"];
$datos["Hz Max"]=$valores["Hz_Max"];
$datos["Filling"]=$valores["Filling"];
$datos["startTime"]=$valores["startTime"];
$datos["endTime"]=$valores["endTime"];

$datos["n_sects"]=$valores["n_sects"];
$datos["n_types"]=$valores["n_types"];
$datos["sections_type[1]"]=$valores["sections_type[1]"];
$datos["sections_type[2]"]=$valores["sections_type[2]"];
$datos["sections_type[3]"]=$valores["sections_type[3]"];
$datos["sections_type[4]"]=$valores["sections_type[4]"];
$datos["sections_type[5]"]=$valores["sections_type[5]"];
$datos["sections_type[6]"]=$valores["sections_type[6]"];
$datos["sections_type[7]"]=$valores["sections_type[7]"];
$datos["sections_type[8]"]=$valores["sections_type[8]"];
$datos["sections_type[9]"]=$valores["sections_type[9]"];
$datos["sections_type[10]"]=$valores["sections_type[10]"];
$datos["len_by_type_array[1]"]=$valores["len_by_type_array[1]"];
$datos["len_by_type_array[2]"]=$valores["len_by_type_array[2]"];
$datos["len_by_type_array[3]"]=$valores["len_by_type_array[3]"];
$datos["len_by_type_array[4]"]=$valores["len_by_type_array[4]"];
$datos["len_by_type_array[5]"]=$valores["len_by_type_array[5]"];
$datos["factor_by_type_array[1]"]=$valores["factor_by_type_array[1]"];
$datos["factor_by_type_array[2]"]=$valores["factor_by_type_array[2]"];
$datos["factor_by_type_array[3]"]=$valores["factor_by_type_array[3]"];
$datos["factor_by_type_array[4]"]=$valores["factor_by_type_array[4]"];
$datos["factor_by_type_array[5]"]=$valores["factor_by_type_array[5]"];
$datos["Density"]=$valores["Density"];
$datos["NominalSpeed"]=$valores["NominalSpeed"];


//echo "strart ".$datos["startTime"]. " endTime ".$valores["endTime"];
			$this->crearExcel($id,$datos);
			echo json_encode($this->obenerResultado($id));
			//echo $id;
			//$this->obenerResultado($id);

				 }

		 function modificar($archivo,$valores,$opciones,$id)
		{

			if(!file_exists($this->temporal.$id)){
				mkdir($this->temporal.$id);
			}
			$correcto=true;
			copy($this->model."/cosim-model.zip", $this->temporal.$id."/cosim-model.zip");
			$zip = new ZipArchive;
			if ($zip->open($this->temporal.$id."/cosim-model.zip") === TRUE)
			{

				$cosim=$this->temporal.$id."/cosim-model/";
				$extraido = $zip->extractTo($cosim);
				$correcto=$extraido;
				$zip->close();
				if ($extraido) {

				    unlink($this->temporal.$id."/cosim-model.zip");
						$fichero =  $cosim.$archivo.'.fmu';
						$nuevo_fichero = $cosim.$archivo.'.zip';
						if (!copy($fichero, $nuevo_fichero)) {
							$correcto=false;
					 }else{

						 unlink($fichero);
						 $zip = new ZipArchive;
		 		    	//en la función open se le pasa la ruta de nuestro archivo (alojada en carpeta temporal)
		 		    	if ($zip->open($nuevo_fichero) === TRUE)
		 		    	{

								$extraido = $zip->extractTo($cosim.$archivo.'/');
								$correcto=$extraido;
				    		$zip->close();
								if ($extraido) {

								 unlink($nuevo_fichero);

		 		          $xml_Document = new DOMDocument ('1.0 ', ' utf-8');
		 		          $xml_Document -> formatOutput = true;
		 		          $xml_Document -> preserveWhiteSpace = false;
		 		          $xml_Document -> load($cosim.$archivo.'/modelDescription.xml');
		 		          $elementos=$xml_Document->getElementsByTagName('ScalarVariable');
									for ($i=0; $i <$elementos->length ; $i++) {
				            $pos = strpos($opciones," ".$elementos->item($i)->getAttribute('name')." ");
				            if ($pos == false)
				            {
				            }else{

				            	if ($valores[$elementos->item($i)->getAttribute('name')]>0){
								$elementos->item($i)->childNodes[0]->setAttribute('start',$valores[$elementos->item($i)->getAttribute('name')]);
								//$elementos->item($i)->childNodes[0]->setAttribute('start',number_format($valores[$elementos->item($i)->getAttribute('name')],"4",",",","));
								}
						}
				          }
									$arr_clientes = array('startTime'=> $valores['startTime'], 'endTime'=> $valores['endTime']);


//Creamos el JSON
									$json_string = json_encode($arr_clientes);
									$file =$cosim.'/time.json';

									file_put_contents($file, $json_string);
									$xml_Document->save($cosim.$archivo.'/modelDescription.xml');
									if ($zip->open($nuevo_fichero, ZIPARCHIVE::CREATE) === true) {
										$this->agregar_zip($cosim.$archivo.'/',"", $zip);
		                $zip->close();
										rename($nuevo_fichero, $fichero);
										$this->rmDir_rf($cosim.$archivo.'/');

										if ($zip->open($this->temporal.$id."/cosim-model.zip", ZIPARCHIVE::CREATE) === true) {
											$this->agregar_zip($cosim,"", $zip);
			                $zip->close();
											$this->rmDir_rf($cosim);
										}
									}

							  }
							}

					 }
				}


			}
		 return $correcto;
		}

		function agregar_zip($dir,$destino, $zip) {
		  //verificamos si $dir es un directorio
		  if (is_dir($dir)) {
		    //abrimos el directorio y lo asignamos a $da
		    if ($da = opendir($dir)) {
		      //leemos del directorio hasta que termine
		      while (($archivo = readdir($da)) !== false) {
		        /*Si es un directorio imprimimos la ruta
		         * y llamamos recursivamente esta función
		         * para que verifique dentro del nuevo directorio
		         * por mas directorios o archivos
		         */
		        if (is_dir($dir . $archivo) && $archivo != "." && $archivo != "..") {
		          if($destino==""){
		            $this->agregar_zip($dir . $archivo . "/",$archivo . "/", $zip);
		          }else{
		            $this->agregar_zip($dir . $archivo . "/",$destino."/".$archivo . "/", $zip);
		          }


		          /*si encuentra un archivo imprimimos la ruta donde se encuentra
		           * y agregamos el archivo al zip junto con su ruta
		           */
		        } elseif (is_file($dir . $archivo) && $archivo != "." && $archivo != "..") {
		          $zip->addFile($dir . $archivo, $destino . $archivo);
		        }
		      }
		      //cerramos el directorio e en el momento
		      closedir($da);
		    }
		  }
		}
		function rmDir_rf($carpeta)
		    {
		      foreach(glob($carpeta . "/*") as $archivos_carpeta){
		        if (is_dir($archivos_carpeta)){
		          $this->rmDir_rf($archivos_carpeta);
		        } else {
		        unlink($archivos_carpeta);
		        }
		      }
		      rmdir($carpeta);
		     }

			function lecturaexcel(){
		 		//$file = FCPATH.'application/files/beneficiarios_mio.xlsx';
		 		$this->load->library('excel');
		 		$file = FCPATH.'application/files/temporal/Time_series_inputs.xlsx';
				$tiempos=array();
		 		$TemperatureFlueGas= array();
		 		$MassFlueGas= array();
		 		$VFFeed= array();
		 		$VFRotaryDryer= array();
				$TemperatureWood= array();
				$TemperatureAir= array();
				$TemperatureRecirculation=array();
				$VFFAir= array();
				$MassWood= array();
				$MassAir= array();
				$MassRecirculation= array();
		 		$excel = PHPExcel_IOFactory::load($file);
		 		$sheet = $excel->getSheet(0);
		 		$highestRow = $sheet->getHighestRow();

		 			/*Recorremos cada hoja donde están los dotos de beneficiarios y familiares*/
		 			for ($row = 2; $row <= $highestRow; $row++){
						array_push($tiempos,$sheet->getCell("A".$row)->getCalculatedValue());
						array_push($TemperatureFlueGas,$sheet->getCell("B".$row)->getCalculatedValue());
						array_push($MassFlueGas,$sheet->getCell("C".$row)->getCalculatedValue());
						array_push($TemperatureAir,$sheet->getCell("D".$row)->getCalculatedValue());
						array_push($MassAir,$sheet->getCell("E".$row)->getCalculatedValue());
						array_push($TemperatureRecirculation,$sheet->getCell("F".$row)->getCalculatedValue());
						array_push($MassRecirculation,$sheet->getCell("G".$row)->getCalculatedValue());
						array_push($VFFAir,$sheet->getCell("H".$row)->getCalculatedValue());
						array_push($VFFeed,$sheet->getCell("I".$row)->getCalculatedValue());
						array_push($VFRotaryDryer,$sheet->getCell("J".$row)->getCalculatedValue());
						array_push($TemperatureWood,$sheet->getCell("K".$row)->getCalculatedValue());
						array_push($MassWood,$sheet->getCell("L".$row)->getCalculatedValue());

		 			}
					$datos=array();
					$datos["tiempos"]=$tiempos;
					$datos["TemperatureFlueGas"]=$TemperatureFlueGas;
					$datos["TemperatureAir"]=$TemperatureAir;
					$datos["TemperatureRecirculation"]=$TemperatureRecirculation;
					$datos["TemperatureWood"]=$TemperatureWood;
					$datos["MassFlueGas"]=$MassFlueGas;
					$datos["MassAir"]=$MassAir;
					$datos["MassRecirculation"]=$MassRecirculation;
					$datos["MassWood"]=$MassWood;
					$datos["VFFeed"]=$VFFeed;
					$datos["VFRotaryDryer"]=$VFRotaryDryer;
					$datos["VFFAir"]=$VFFAir;
					return $datos;


		 	}
		 function crearExcel($id,$valores) {
			  $this->load->library('excel');
			 $phpExcel = new PHPExcel;

$writer = PHPExcel_IOFactory::createWriter($phpExcel, "Excel2007");
$sheet = $phpExcel ->getActiveSheet();
$sheet ->getCell('A1')->setValue("CAMPO");
$sheet ->getCell('B1')->setValue("VALOR");
$i=2;
		foreach ($valores as $item => $value){
		 $sheet ->getCell('A'.$i)->setValue($item);
		 $sheet ->getCell('B'.$i)->setValue($value);
		 $i=$i+1;
		}



$writer->save($this->temporal.$id.'/datos.xlsx');
		 }
		 function lecturaexcel_txt($id){
		 //$file = FCPATH.'application/files/beneficiarios_mio.xlsx';
		 $this->load->library('excel');
		 $file = FCPATH.'application/files/temporal/Time_series_inputs.xlsx';
		 $TemperatureFlueGas= fopen($this->temporal.$id.'/TemperatureFlueGas.txt', "w");
		 $TemperatureWood= fopen($this->temporal.$id.'/TemperatureWood.txt', "w");
		 $MassFlueGas= fopen($this->temporal.$id.'/MassFlueGas.txt', "w");
		 $VFFeed= fopen($this->temporal.$id.'/VFFeed.txt', "w");
		 $VFRotaryDryer= fopen($this->temporal.$id.'/VFRotaryDryer.txt', "w");
		 $VFFAir= fopen($this->temporal.$id.'/VFFAir.txt', "w");
		 $MassWood= fopen($this->temporal.$id.'/MassWood.txt', "w");
                 $MassAir= fopen($this->temporal.$id.'/MassAir.txt', "w");
		 $TemperatureAir= fopen($this->temporal.$id.'/TemperatureAir.txt', "w");
		 $MassRecirculation= fopen($this->temporal.$id.'/MassRecirculation.txt', "w");
		 $TemperatureRecirculation= fopen($this->temporal.$id.'/TemperatureRecirculation.txt', "w");
		 $excel = PHPExcel_IOFactory::load($file);
		 $sheet = $excel->getSheet(0);
		 $highestRow = $sheet->getHighestRow();
		 	fwrite($TemperatureFlueGas, "#1" . PHP_EOL);
			fwrite($MassFlueGas, "#1" . PHP_EOL);
			fwrite($MassWood, "#1" . PHP_EOL);
			fwrite($VFFeed, "#1" . PHP_EOL);
			fwrite($VFRotaryDryer, "#1" . PHP_EOL);
			fwrite($TemperatureWood, "#1" . PHP_EOL);
			fwrite($VFFAir, "#1" . PHP_EOL);
			fwrite($MassAir, "#1" . PHP_EOL);
			fwrite($TemperatureAir, "#1" . PHP_EOL);
			fwrite($MassRecirculation, "#1" . PHP_EOL);
			fwrite($TemperatureRecirculation, "#1" . PHP_EOL);
			fwrite($TemperatureFlueGas, "double TemperatureFlueGas(".($highestRow-1).",2)   # comment line" . PHP_EOL);
			fwrite($TemperatureWood, "double TemperatureWood(".($highestRow-1).",2)   # comment line" . PHP_EOL);
			fwrite($MassFlueGas, "double MassFlueGas(".($highestRow-1).",2)   # comment line" . PHP_EOL);
			fwrite($MassWood, "double MassWood(".($highestRow-1).",2)   # comment line" . PHP_EOL);
			fwrite($VFFeed, "double VFFeed(".($highestRow-1).",2)   # comment line" . PHP_EOL);
			fwrite($VFRotaryDryer, "double VFRotaryDryer(".($highestRow-1).",2)   # comment line" . PHP_EOL);
			fwrite($VFFAir, "double VFFAir(".($highestRow-1).",2)   # comment line" . PHP_EOL);
			fwrite($MassAir, "double MassAir(".($highestRow-1).",2)   # comment line" . PHP_EOL);
			fwrite($TemperatureAir, "double TemperatureAir(".($highestRow-1).",2)   # comment line" . PHP_EOL);
			fwrite($MassRecirculation, "double MassRecirculation(".($highestRow-1).",2)   # comment line" . PHP_EOL);
			fwrite($TemperatureRecirculation, "double TemperatureRecirculation(".($highestRow-1).",2)   # comment line" . PHP_EOL);



			 /*Recorremos cada hoja donde están los dotos de beneficiarios y familiares*/
			 for ($row = 2; $row <= $highestRow; $row++){
				 fwrite($TemperatureFlueGas, $sheet->getCell("A".$row)->getCalculatedValue()." ".($sheet->getCell("B".$row)->getCalculatedValue() + 273.15). PHP_EOL);
				 fwrite($TemperatureWood, $sheet->getCell("A".$row)->getCalculatedValue()." ".($sheet->getCell("K".$row)->getCalculatedValue() + 273.15). PHP_EOL);
				 fwrite($MassFlueGas, $sheet->getCell("A".$row)->getCalculatedValue()." ".$sheet->getCell("C".$row)->getCalculatedValue() . PHP_EOL);
				 fwrite($VFFeed, $sheet->getCell("A".$row)->getCalculatedValue()." ".$sheet->getCell("I".$row)->getCalculatedValue() . PHP_EOL);
				 fwrite($VFRotaryDryer, $sheet->getCell("A".$row)->getCalculatedValue()." ".$sheet->getCell("J".$row)->getCalculatedValue() . PHP_EOL);
				 fwrite($VFFAir, $sheet->getCell("A".$row)->getCalculatedValue()." ".$sheet->getCell("H".$row)->getCalculatedValue() . PHP_EOL);
				fwrite($MassWood, $sheet->getCell("A".$row)->getCalculatedValue()." ".$sheet->getCell("L".$row)->getCalculatedValue() . PHP_EOL);
				fwrite($TemperatureAir, $sheet->getCell("A".$row)->getCalculatedValue()." ".($sheet->getCell("D".$row)->getCalculatedValue() + 273.15). PHP_EOL);
				fwrite($MassAir, $sheet->getCell("A".$row)->getCalculatedValue()." ".$sheet->getCell("E".$row)->getCalculatedValue() . PHP_EOL);
				fwrite($TemperatureRecirculation, $sheet->getCell("A".$row)->getCalculatedValue()." ".($sheet->getCell("F".$row)->getCalculatedValue() +273.15 ). PHP_EOL);
				fwrite($MassRecirculation, $sheet->getCell("A".$row)->getCalculatedValue()." ".$sheet->getCell("G".$row)->getCalculatedValue() . PHP_EOL);

			 }
			 fclose($TemperatureFlueGas);
			 fclose($MassFlueGas);
			 fclose($VFFeed);
			 fclose($VFRotaryDryer);
			 fclose($VFFAir);
			 fclose($TemperatureWood);
			fclose($MassWood);
			fclose($MassAir);
			fclose($MassRecirculation);
			fclose($TemperatureAir);
			fclose($TemperatureRecirculation);

 	 }
	 public function comprobarFichero2( $directorio)
	 {
		 $buscando=true;
		 while ($buscando) {
			 $fn = fopen($directorio,"r");

  		  while(! feof($fn))  {
	  			$result = fgets($fn);
	  			if (trim($result)=="1") {
	  				$buscando=false;
	  			}else {

	  			}
  		  }

  		  fclose($fn);
		 }


	 }
	 public function comprobarFichero( $directorio)
	 {
		 $buscando=true;
		 while ($buscando) {
			 sleep(10);
			 $buscando=file_exists($directorio);
		 }


	 }

	 public function obenerResultado ($id){


		$directorio=$this->temporal.$id;
		$file= fopen($this->salida.'SYNC.LCK', "w");
		fwrite($file, "1" . PHP_EOL);
		fclose($file);
		$ficheros=scandir($directorio);

	 	for ($i=0; $i <count($ficheros) ; $i++) {
	 		if(is_file($directorio.'/'.$ficheros[$i])){
				$file_path = $directorio.'/'.$ficheros[$i];
				$file_ext = pathinfo($file_path, PATHINFO_EXTENSION);
				if($file_ext=="txt"){
					copy($directorio.'/'.$ficheros[$i], $this->entrada.$ficheros[$i]);
				}elseif ($file_ext=="zip") {
					copy($directorio.'/'.$ficheros[$i], $this->model.$ficheros[$i]);
				}
			}
	 	}
                unlink($this->model.'cosim-model.zip');
               if (file_exists($this->model.'cosim-model.zip')) {
			//echo "no eliminado model";
		}else{
                   copy($this->temporal.$id."/cosim-model.zip",$this->model.'cosim-model.zip');
                   if (file_exists($this->model.'cosim-model.zip')) {
			//echo "copiado";
		   }else{
                   	//echo "no copiado";
                   }
               }


		if (file_exists($this->model.'SYNC.LCK')) {
			unlink($this->model.'SYNC.LCK');
		}
		$this->comprobarFichero($this->salida.'SYNC.LCK');
		$resultados=array();
		if(file_exists($this->salida.'output.csv')){
			$resultado["correcto"]=true;
			copy($this->salida.'output.csv', $directorio.'\output.csv');
			$tiempos=array();
			$resumenes=array(0=>"{ModeloParticulas}.mi.TinGas",1=>"{ModeloParticulas}.mi.ToutGas",2=>"{ModeloParticulas}.mi.RHoutWood",3=>"{ModeloParticulas}.mi.XoutH2O",4=>"{ModeloParticulas}.mi.MWood",5=>"{ModeloParticulas}.mi.VGas");
			$titulos=array(0=>"Temperature Gas In",1=>"Temperature Gas Out",2=>"Product Humidity Out",3=>"Gas Humidity Out",4=>"MassFlow Product Out",5=>"VolumetricFlow Air Out");
			$medidas=array(0=>"ºC",1=>"ºC",2=>"%",3=>"%",4=>"t/h",5=>"m3/h");
			$TemperaturesGas=array(0=>"{ModeloParticulas}.mi.TinGas",1=>"{ModeloParticulas}.mi.ToutGas");//14
			$TemperaturesParticles=array(0=>"{ModeloParticulas}.mi.Tp_1_in",1=>"{ModeloParticulas}.mi.Tp_1_out",2=>"{ModeloParticulas}.mi.Tp_2_in",3=>"{ModeloParticulas}.mi.Tp_2_out",4=>"{ModeloParticulas}.mi.Tp_3_in",5=>"{ModeloParticulas}.mi.Tp_3_out");//15
			$MassFlows=array(0=>"{ModeloParticulas}.mi.MWood");//12
			$EvapRate=array(0=>"{ModeloParticulas}.mi.EvapRate");
			$derLargeParticles=array(0=>"{ModeloParticulas}.mi.relMaxPartBal");
			$Humidity=array(0=>"{ModeloParticulas}.mi.RHinWood",1=>"{ModeloParticulas}.mi.RHoutWood",2=>"{ModeloParticulas}.mi.XinH2O",3=>"{ModeloParticulas}.mi.XoutH2O");//13
			$Balances=array(0=>"{ModeloParticulas}.mi.enthalpy_bal",1=>"{ModeloParticulas}.mi.mass_bal",2=>"{ModeloParticulas}.mi.part_bal",3=>"{ModeloParticulas}.mi.water_bal");//16
			$VolumetricFlowRate=array(0=>"{ModeloParticulas}.mi.VGas");//17
			$colores=array(0=>"blue",1=>"orange",2=>"green",3=>"red",4=>"purple",5=>"brown");//17
			$index=array();//18
			$valores=array();//19

			$i=-1;
			$fp = fopen ($directorio.'\output.csv',"r");
					$data = fgetcsv ($fp, 1000, ",");
					for ($j=0; $j < count($data) ; $j++) {
						$index[$j]=$data[$j];
						$valores[$data[$j]]=array();
					}
					while ($data = fgetcsv ($fp, 1000, ",")) {

							if(intval($data[0])==(($i+1)*1)){
								$i=$i+1;
								array_push($tiempos,intval($data[0]));
								for ($j=1; $j <count($data) ; $j++) {
									array_push($valores[$index[$j]],$data[$j]);
								}

							}




					}
					fclose($fp);
					$resultados=array();
					$resultados["correcto"]=true;
					$resultados["tiempos"]=$tiempos;
					$resultados["TemperaturesGas"]=$TemperaturesGas;
					$resultados["TemperaturesParticles"]=$TemperaturesParticles;
					$resultados["MassFlows"]=$MassFlows;
					$resultados["EvapRate"]=$EvapRate;
					$resultados["Humidity"]=$Humidity;
					$resultados["Balances"]=$Balances;
					$resultados["VolumetricFlowRate"]=$VolumetricFlowRate;
					$resultados["valores"]=$valores;
					$resultados["colores"]=$colores;
					$resultados["resumenes"]=$resumenes;
					$resultados["titulos"]=$titulos;
					$resultados["medidas"]=$medidas;
					$resultados["derLargeParticles"]=$derLargeParticles;
					
					$zip = new ZipArchive;
					if ($zip->open($directorio.'/datos.zip', ZIPARCHIVE::CREATE) === true) {
						copy($directorio.'\output.csv','output.csv');
						$zip->addFile('output.csv');
						copy($directorio.'/datos.xlsx','datos.xlsx');
						$zip->addFile('datos.xlsx');
						copy($this->temporal.'Time_series_inputs.xlsx','Time_series_inputs.xlsx');
						$zip->addFile('Time_series_inputs.xlsx');

						$zip->close();
						unlink('datos.xlsx');
						unlink('Time_series_inputs.xlsx');
						$resultados["archivo"]='application/files/temporal/'.$id.'\datos.zip';
						$resultados["ruta"]=$directorio.'\datos.xlsx';
					}else{
						$resultados["archivo"]="datos no creado";
					}					



		

		}else{
			$resultado["correcto"]=false;
			copy($this->salida.'error.log', $directorio.'\error.log');
			$fp = fopen($directorio.'\error.log', "r");
			$mensaje="";
			$mostrar=false;
			while (!feof($fp)){
			    $linea = fgets($fp);
			    if ($mostrar) {
			      $mensaje=$mensaje."<p>".$linea."<p>";
			    }else{
			      $pos = strpos($linea, 'ERROR [main]');
			      if ($pos === false){
			        //$mostrar=false;
			      }else{
			        $mostrar=true;
			      }
			      if ($mostrar) {
			        $mensaje=$mensaje. "<p>".str_replace("ERROR [main]", "", $linea)."<p>";

			      }
			    }

			}
			fclose($fp);
			$resultado["mensaje"]=$mensaje;
		}

			  return $resultados;

	 }
	public function zip(){
	$id = "141";
	$directorio=$this->temporal.$id;
	$resultado=array();
	$zip = new ZipArchive;
					if ($zip->open($directorio.'/datos.zip', ZIPARCHIVE::CREATE) === true) {
						copy($directorio.'\output.csv','output.csv');
						$zip->addFile('output.csv');
						copy($directorio.'/datos.xlsx','datos.xlsx');
						$zip->addFile('datos.xlsx');
						$zip->close();
						unlink('datos.xlsx');
						$resultados["archivo"]='application/files/temporal/'.$id.'\datos.zip';
						$resultados["ruta"]=$directorio.'\datos.xlsx';
					}else{
						$resultados["archivo"]="datos no creado";
					}

}

	 public function obenerResultado2 ($id){


		$directorio=$this->temporal.$id;
		$file= fopen($this->salida.'SYNC.LCK', "w");
		fwrite($file, "1" . PHP_EOL);
		fclose($file);
		$ficheros=scandir($this->temporal.$id.'/');

	 	for ($i=0; $i <count($ficheros) ; $i++) {
	 		if(is_file($this->temporal.$id.'/'.$ficheros[$i])){
				copy($this->temporal.$id.'/'.$ficheros[$i], $this->input.$ficheros[$i]);

			}
	 	}
		copy($this->temporal.$id."/cosim-model.zip",$this->salida.'cosim-model.zip');
		unlink($this->model.'SYNC.LCK');
		$this->comprobarFichero($this->salida.'SYNC.LCK');
		copy($this->salida.'output.csv', $this->temporal.$id.'/output.csv');
		$tiempos=array();
		$tabla1=array();
		$tabla2=array();
		$tabla3=array();
		$tabla4=array();
		$tabla5=array();
		$tabla6=array();
		$i=-1;
		$fp = fopen ($this->temporal.$id.'/output.csv',"r");
				$data = fgetcsv ($fp, 1000, ",");
				while ($data = fgetcsv ($fp, 1000, ",")) {

					if(intval($data[0])==(($i+1)*10)){
						$i=$i+1;
						array_push($tiempos,intval($data[0]));
						array_push($MassAir,$data[12]);
						array_push($MassDyerOutlet,$data[13]);
						array_push($MassFlueGas,$data[14]);
						array_push($MassWood,$data[15]);
						array_push($TemperatureAir,$data[16]);
						array_push($TemperatureDryerOutlet,$data[17]);
						array_push($TemperatureFlueGas,$data[18]);
						array_push($TemperatureWood,$data[19]);
						array_push($VFFeed,$data[20]);
						array_push($VFRotaryDryer,$data[21]);
						array_push($VFair,$data[22]);

					}


				}
				fclose($fp);
				$resulados=array();
				$resultados["tiempos"]=$tiempos;
				$resultados["MassAir"]=$MassAir;
				$resultados["MassDyerOutlet"]=$MassDyerOutlet;
				$resultados["MassFlueGas"]=$MassFlueGas;
				$resultados["MassWood"]=$MassWood;
				$resultados["TemperatureAir"]=$TemperatureAir;
				$resultados["TemperatureDryerOutlet"]=$TemperatureDryerOutlet;
				$resultados["TemperatureFlueGas"]=$TemperatureFlueGas;
				$resultados["TemperatureWood"]=$TemperatureWood;
				$resultados["VFFeed"]=$VFFeed;
				$resultados["VFRotaryDryer"]=$VFRotaryDryer;
				$resultados["VFair"]=$VFair;

			  return $resultados;


	 }


}
