<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct() {
		 parent::__construct();
		  //$this->load->model('login_model');
			//$this->load->library('session');
	 }

	public function index()
	{
		if($this->session->has_userdata('user')){
			redirect(base_url(''));
		}else{
			$datos=array();
			$datos["incorrecto"]="";
			echo $this->load->view('login/login_view', $datos, TRUE);
		}


	}
	public function guardar()
	{
		/*if($this->session->has_userdata('user')){
			redirect(base_url(''));
		}else{
			$datos=array();
			$datos["incorrecto"]="";
			echo $this->load->view('login/login_view', $datos, TRUE);
		}*/
		$_SESSION['user']='prueba';
		$this->session->set_userdata('user',"prueba");
		echo "session ".$this->session->userdata('user');
			echo "session ".$_SESSION['user'];
			var_dump($_SESSION);



	}
	public function login() {
		if($this->session->has_userdata('user')){
			redirect(base_url(''));
		}else{
			$user=$this->input->post('user', TRUE);
			$password=md5($this->input->post('password', TRUE));
			$this->load->library('excel');
			$file = FCPATH.'usuarios.xlsx';

			$excel = PHPExcel_IOFactory::load($file);
			$sheet = $excel->getSheet(0);
			$highestRow = $sheet->getHighestRow();
			$row=1;
			$encontrado=false;
			while ($row <= $highestRow && !$encontrado) {
				$encontrado=($user==$sheet->getCell("A".$row)->getCalculatedValue())&&($password==$sheet->getCell("B".$row)->getCalculatedValue());
				//echo $user."==".$sheet->getCell("A".$row)->getCalculatedValue()." && ".$password."==".$sheet->getCell("B".$row)->getCalculatedValue();
				$row ++;
			}
			if($encontrado){
						$this->session->set_userdata('user',$user);
					redirect('http://'.$_SERVER["HTTP_HOST"].'/');
				}else{
					//echo " no encontrado";
					$datos=array();
					$datos["incorrecto"]="Usuario o password invalido";
					echo $this->load->view('login/login_view', $datos, TRUE);

				}
		}

	}
	public function logout(){
		$this->session->sess_destroy();
		redirect('http://'.$_SERVER["HTTP_HOST"].'/index.php/Login');
	}


}
