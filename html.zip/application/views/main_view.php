<!doctype html>
<html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="<?php echo 'http://'.$_SERVER["HTTP_HOST"].'/assets/js/custom.js'?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.3/jspdf.debug.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<head> <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href="<?php echo 'http://'.$_SERVER["HTTP_HOST"].'/assets/css/style.css'?>" rel="stylesheet" type="text/css">



</head>
<body>


<div class="header" >
	<div class="menu-header">
		<ul class="menu">
			<li><a id="menu1" class="green" hrf="#" onclick="volver1()" style="cursor: pointer;">I.INPUTS</a></li>
			<li><a id="menu2" hrf="#">II.SIMULATION</a></li>
			<li><a id="menu3" hrf="#">III.RESULTS</a></li>
			<li><a  hrf="#" onclick="window.location.href = '<?php echo 'http://'.$_SERVER["HTTP_HOST"].'/index.php/Login/logout'?>';" style="cursor: pointer;">LOGOUT</a></li>

		</ul>

	</div>





		<img class="logo" src="<?php echo 'http://'.$_SERVER["HTTP_HOST"].'/assets/img/logo.png'?>">




</div>

<section id="full">

<section id="block">


<div><h1 class="static">STATIC DATA</h1></div>

		<form id="datos">


			<fieldset>

		<h2 class="title">AMBIENT CONDITIONS</h2>

		<ul>

			<li>
				<div>
		 			 <label title="Ambient Temperature" for="temperature-ambient">T [ºC]</label>
		  			<input type="number" name="T_particula_amb" value="18">
				</div>
			</li>

			<li>
				<div>
		 			 <label title="Ambient Pressure" for="pressure-ambient">P [Pa]</label>
		  			<input type="number" name="P_atm" value="101325">
				</div>
			</li>
                         <li>
				<div>
		 			 <label title="Relative Humidity" for="pressure-ambient">Rel. Hum. [%]</label>
		  			<input type="number" name="relative_humidity_param" value="30">
				</div>
			</li>

		</ul>

		<h2 class="title">PRODUCT CHARACTERISTICS</h2>
		<ul>

			<li>
				<div>
		 			 <label title="Bulk density" for="density-wood">Density particle [kg/m3]</label>
		  			<input type="number" name="rho_s" value="530">
				</div>
			</li>

			<li>
				<div>
		 			 <label title="Wet Basis Moisture Content" for="humidity-wood">Hum Wet Basis [%]</label>
		  			<input type="number" name="init_hum" value="40">
				</div>
			</li>

		</ul>

		<h2 class="title">PARTICLES | SIZE [mm] & DISTRIBUTION [%]</h2>

		<ul class="particules">

			<li>
				<div>
		 			 <label for="<1mm">dp1</label>
		  			<input type="number" name="d_p[1]" value="1.5">

				</div>
			</li>

			<li>
				<div>
		 			 <label for="<1mm">dp2</label>
		  			<input type="number" name="d_p[2]" value="3">

				</div>
			</li>
			<li>
				<div>
		 			 <label for="<1mm">dp3</label>
		  			<input type="number" name="d_p[3]" value="4.5">

				</div>
			</li>
			<li>
				<div>
		 			 <label for="<1mm">dp4</label>
		  			<input type="number" name="d_p[4]" value="6">

				</div>
			</li>
			<li>
				<div>
		 			 <label for="<1mm">dp5</label>
		  			<input type="number" name="d_p[5]" value="7.5">

				</div>
			</li>
</ul>
<ul class="particules">
			<li>
				<div>
		 			  <label title="The sum of size distribution sd1, sd2, sd3, sd4 and sd5 should be 100%!"for="<6mm">sd1</label>
		  			<input class="sd" type="number" name="size_dist[1]" value="14">

				</div>
			</li>
			<li>
				<div>
		 			  <label title="The sum of size distribution sd1, sd2, sd3, sd4 and sd5 should be 100%!"for="<6mm">sd2</label>
		  			<input class="sd" type="number" name="size_dist[2]" value="24">

				</div>
			</li>
			<li>
				<div>
		 			  <label title="The sum of size distribution sd1, sd2, sd3, sd4 and sd5 should be 100%!"for="<6mm">sd3</label>
		  			<input class="sd" type="number" name="size_dist[3]" value="26">

				</div>
			</li>
			<li>
				<div>
		 			  <label title="The sum of size distribution sd1, sd2, sd3, sd4 and sd5 should be 100%!"for="<6mm">sd4</label>
		  			<input class="sd" type="number" name="size_dist[4]" value="19">

				</div>
			</li>
			<li>
				<div>
		 			  <label title="The sum of size distribution sd1, sd2, sd3, sd4 and sd5 should be 100%!"for="<6mm">sd5</label>
		  			<input class="sd" type="number" name="size_dist[5]" value="17">

				</div>
			</li>


		</ul>



		<h2 title="Gas Mass Fraction of species in the Combustion Gas Source: It should sum 100%!"class="title">INLET DRYER GAS SOURCE | MASS FRACTION [%]</h2>

		<ul>

			<li>
				<div>
		 			 <label for="h2o-combustiongas">H2O</label>
		  			<input class="combustiongas" type="number" name="H2O_ini" value="10.66">

				</div>
			</li>

			<li>
				<div>
		 			 <label for="co2-combustiongas">CO2</label>
		  			<input class="combustiongas" type="number" name="CO2_ini" value="3.12">

				</div>
			</li>

			<li>
				<div>
		 			 <label for="n2-combustiongas">N2</label>
		  			<input class="combustiongas" type="number" name="N2_ini" value="68.06">

				</div>
			</li>

			<li>
				<div>
		 			 <label for="o2-combustiongas">O2</label>
		  			<input class="combustiongas" type="number" name="O2_ini" value="18.16">

				</div>
			</li>

		</ul>

		<h2 title="Gas Mass Fraction of species in the Recirculation Gas Source: It should sum 100%!"class="title">RECIRCULATION GAS SOURCE | MASS FRACTION [%]</h2>

		<ul>

			<li>
				<div>
		 			 <label for="h2o-recirculation">H2O</label>
		  			<input class="recirculation" type="number" name="H2O_1" value="10">

				</div>
			</li>

			<li>
				<div>
		 			 <label for="co2-recirculation">CO2</label>
		  			<input class="recirculation" type="number" name="CO2_1" value="5">

				</div>
			</li>

			<li>
				<div>
		 			 <label for="n2-recirculation">N2</label>
		  			<input class="recirculation" type="number" name="N2_1" value="70">

				</div>
			</li>

			<li>
				<div>
		 			 <label for="o2-recirculation">O2</label>
		  			<input class="recirculation" type="number" name="O2_1" value="15">

				</div>
			</li>

		</ul>




		<h2 class="title">ROTARY DRYER CHARACTERISTICS </h2>
		<ul class="feeder">


			<li>
				<div>
		 			 <label for="inlets-s2">Diameter [m]</label>
		  			<input type="number" name="D_dryer" value="3.3">

				</div>
			</li>

			<li>
				<div>
		 			 <label for="module-1">Length [m]</label>
		  			<input type="number" name="L" value="12.5">

				</div>
			</li>



		</ul>


		<ul class="feeder">
			<li>

				<div>
		 			 <label title="Nominal Speed of the rotary dryer" for="filling">Speed [rpm]</label>
		  			<input type="number" name="NominalSpeed" value="5.9">

				</div>
			</li>

			<li>
				<div>
		 			 <label title="Total number of sections in which the rotary dryer is divided"for="inlets-s2">n_sects</label>
		  			<input type="number" name="n_sects" value="10">

				</div>
			</li>

			<li>
				<div>
		 			 <label title="Total number of different types associated with the sections" for="module-1">n_types</label>
		  			<input type="number" name="n_types" value="5">

				</div>
			</li>



		</ul>



					<ul class="feeder">

			<li>
				<div>
		 			 <label title="Type of section 1" for="<1mm">secc1</label>
		  			<input type="number" name="sections_type[1]" value="1">

				</div>
			</li>

			<li>
				<div>
		 			 <label title="Type of section 2" for="<1mm">secc2</label>
		  			<input type="number" name="sections_type[2]" value="1">

				</div>
			</li>
			<li>
				<div>
		 			 <label f title="Type of section 3"or="<1mm">secc3</label>
		  			<input type="number" name="sections_type[3]" value="1">

				</div>
			</li>
			<li>
				<div>
		 			 <label title="Type of section 4" for="<1mm">secc4</label>
		  			<input type="number" name="sections_type[4]" value="1">

				</div>
			</li>
			<li>
				<div>
		 			 <label title="Type of section 5" for="<1mm">secc5</label>
		  			<input type="number" name="sections_type[5]" value="1">

				</div>
			</li>
			</ul>

			<ul class="feeder">
			<li>
				<div>
		 			 <label for="<1mm">secc6</label>
		  			<input type="number" name="sections_type[6]" value="1">

				</div>
			</li>

			<li>
				<div>
		 			 <label title="Type of section 6" for="<1mm">secc7</label>
		  			<input type="number" name="sections_type[7]" value="1">

				</div>
			</li>
			<li>
				<div>
		 			 <label title="Type of section 8" for="<1mm">secc8</label>
		  			<input type="number" name="sections_type[8]" value="1">

				</div>
			</li>
			<li>
				<div>
		 			 <label title="Type of section 9" for="<1mm">secc9</label>
		  			<input type="number" name="sections_type[9]" value="1">

				</div>
			</li>
			<li>
				<div>
		 			 <label title="Type of section 10" for="<1mm">secc10</label>
		  			<input type="number" name="sections_type[10]" value="1">

				</div>
			</li>
		</ul>

			<ul class="feeder">
			<li>
				<div>
		 			 <label title="Total length of sections type 1" for="<1mm">lenT1</label>
		  			<input type="number" name="len_by_type_array[1]" value="1.25">

				</div>
			</li>

			<li>
				<div>
		 			 <label title="Total length of sections type 2" for="<1mm">lenT2</label>
		  			<input type="number" name="len_by_type_array[2]" value="0">

				</div>
			</li>
			<li>
				<div>
		 			 <label title="Total length of sections type 3" for="<1mm">lenT3</label>
		  			<input type="number" name="len_by_type_array[3]" value="0">

				</div>
			</li>
			<li>
				<div>
		 			 <label title="Total length of sections type 4" for="<1mm">lenT4</label>
		  			<input type="number" name="len_by_type_array[4]" value="0">

				</div>
			</li>
			<li>
				<div>
		 			 <label title="Total length of sections type 5" for="<1mm">lenT5</label>
		  			<input type="number" name="len_by_type_array[5]" value="0">

				</div>
			</li>
		</ul>


		</ul>

			<ul class="feeder">
			<li>
				<div>
		 			 <label title="Velocity factor of sections type 1: >1 accelerating, <1 decelerating" for="<1mm">factT1</label>
		  			<input type="number" name="factor_by_type_array[1]" value="1">

				</div>
			</li>

			<li>
				<div>
		 			 <label title="Velocity factor of sections type 2: >1 accelerating, <1 decelerating" for="<1mm">factT2</label>
		  			<input type="number" name="factor_by_type_array[2]" value="1">

				</div>
			</li>
			<li>
				<div>
		 			 <label title="Velocity factor of sections type 3: >1 accelerating, <1 decelerating" for="<1mm">factT3</label>
		  			<input type="number" name="factor_by_type_array[3]" value="1">

				</div>
			</li>
			<li>
				<div>
		 			 <label title="Velocity factor of sections type 4: >1 accelerating, <1 decelerating" for="<1mm">factT4</label>
		  			<input type="number" name="factor_by_type_array[4]" value="1">

				</div>
			</li>
			<li>
				<div>
		 			 <label title="Velocity factor of sections type 5: >1 accelerating, <1 decelerating" for="<1mm">factT5</label>
		  			<input type="number" name="factor_by_type_array[5]" value="1">

				</div>
			</li>
		</ul>

		<h2 class="title" style="display:none">HOPPER</h2>
		<ul style="display:none">


			<li>

				<div>
		 			 <label for="hopper-diameter">Diameter [m]</label>
		  			<input type="number" name="hopper_Diameter" value="2">

				</div>
			</li>

			<li>
				<div>
		 			 <label for="hopper-height">Height [m]</label>
		  			<input type="number" name="hopper_Height" value="5">

				</div>
			</li>

		</ul>

		<h2 class="title">FEEDER SCREW</h2>

		<ul class="feeder">


			<li>

				<div>
		 			 <label title="Thread diameter" for="feeder-df">Df [m]</label>
		  			<input type="number" name="Df" value="0.35">

				</div>
			</li>

			<li>
				<div>
		 			 <label title="Tube diameter" for="feeder-ds">Ds [m]</label>
		  			<input type="number" name="Ds" value="0.133">

				</div>
			</li>

			<li>
				<div>
		 			 <label title="Pitch" for="feeder-p">P [m]</label>
		  			<input type="number" name="Pitch" value="0.35">

				</div>
			</li>

		</ul>

		<ul class="feeder">


			<li>

				<div>
		 			 <label title="Maximum velocity of the screw" for="rpm-max">Max Speed [rpm]</label>
		  			<input type="number" name="RPM_Max"  value="50">

				</div>
			</li>

			<li>
				<div>
		 			 <label title="Maximum frequency of the electric motor" for="hz-max">Max Freq. [Hz]</label>
		  			<input type="number" name="Hz_Max" value="50">

				</div>
			</li>


		</ul>

		<ul class="feeder">


			<li>

				<div>
		 			 <label for="filling">Filling</label>
		  			<input type="number" name="Filling" value="0.9">

				</div>
			</li>

			<li>

				<div>
		 			 <label title="Density of the product" for="filling">Density [kg/m3]</label>
		  			<input type="number" name="Density" value="250">

				</div>
			</li>



		</ul>

		<ul class="feeder">






		</ul>





			</fieldset>
			<input type="hidden" name="startTime" value="0" id="startTime">
			<input type="hidden" name="endTime" value="500" id="endTime">
		</form>

	</section>

<section id="block-two" class="block-two">


<div class="derecha">

<div class="time">
	<form class="" id="add_ficheros" method="post">
		<input type="file" id="subir_archivo" name="subir_archivo" style="display:none"/>
	</form>
	<h1 class="titulo">TIME SERIES DATA INPUT</h1>
	<form method="get" action="<?php echo 'http://'.$_SERVER["HTTP_HOST"].'/assets/Time_series_inputs.xlsx'?>">
	 <button class="click" type="submit">CSV TEMPLATE</button>
</form>
		<button class="click" name="button-two" onclick="document.getElementById('subir_archivo').click()">CSV UPLOAD</button>
	</div>



</div>

<div>
	<img class="machine" src="<?php echo 'http://'.$_SERVER["HTTP_HOST"].'/assets/img/Imagen1.png'?>" alt="machine">
	<a onclick="subir()" class="next" href="#"><img  src="<?php echo 'http://'.$_SERVER["HTTP_HOST"].'/assets/img/next.png'?>" alt="next"> </a>
</div>




</section>

<section id="block-three" class="block-three">


<div class="derecha-2">



		<h1 class="titulo">TIME SERIES DATA</h1>




	<div class="container-top y">

		<div class="grafic one">
			<h4>Temperature</h4>
			<canvas class="click"id="myChart1"></canvas></div>
		<div class="grafic two">
			<h4>Mass Flow</h4>
			<canvas class="click" id="myChart2"></canvas>
		</div>


	</div>

	<div class="container-down">

		<div class="grafic three"><h4>Actuators percentage speed</h4><canvas class="click" id="myChart3"></canvas></div>
		<div class="grafic buttons bright">
			<div class="float">
				<input type="hidden" name="startTimeInicial" value="0" id="startTimeInicial">
				<h4> Simulation Time [s] <img class="click" src="<?php echo 'http://'.$_SERVER["HTTP_HOST"].'/assets/img/information2.png'?>" onclick="abrirInformacion()" width="14"/> </h4>
				<input type="number" name="endTimeInicial" value="500" id="endTimeInicial">
			<button class="run" name="button" onclick="preguntar()">RUN</button>
			<a id="envioIncorrecto" style="display:none;" class="incorrect" href="#"><img  src="<?php echo 'http://'.$_SERVER["HTTP_HOST"].'/assets/img/incorrect.png'?>" alt="next"> </a>
			<a id="envioCorrecto" style="display:none;" class="incorrect" href="#"><img  src="<?php echo 'http://'.$_SERVER["HTTP_HOST"].'/assets/img/check.png'?>" style="height: 47px;" alt="next"> </a>
			</div>
			<button id="resultados"  class="results click" name="button-two" onclick="mostrarResultados()" disabled>RESULTS</button>

	 	</div>


	</div>


</div>
<div id="informacion" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close" onclick="cerrarInformacion()">&times;</span>
    <div>The simulation time should be chosen according to the input parameters. The simulation should be run until the convergence (Balances should be 0). The results are not representative in case the balances are not 0.</div>
  </div>

</div>
<div id="preguntarMoal" class="modal">

  <!-- Modal content -->
	<div class="modal-content-pregunta">
     <div class="modal-body">
        If you press RUN the co-simulation will start and cannot be stopped. Please be sure to introduce the appropiate values before running the co-simulation.
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">

<button type="button" class="btn btn-danger click" data-dismiss="modal" onclick="enviar()">Ok</button>
<button type="button" class="btn btn-danger" data-dismiss="modal" onclick="cancelar()" style="background-color: rgba(0,0,0,0.4);">Cancel</button>
      </div>
  </div>

</div>
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close" onclick="cerrarModal()">&times;</span>
    <div id="texto"></div>
  </div>

</div>

<div id="procesandoModal" class="modal">

 

  <!-- Modal content -->

  <div class="modal-content-animation">

    <h3>Waiting for the results</h3>

                               <img src="<?php echo 'http://'.$_SERVER["HTTP_HOST"].'/assets/img/loadin_gif.gif'?>" alt="this slowpoke moves" />

  </div>

 

</div>
<div>
	<a onclick="volver1()" class="pre" href="#"><img  src="<?php echo 'http://'.$_SERVER["HTTP_HOST"].'/assets/img/pre.png'?>" alt="pre"> </a>
</div>

</section>

<section id="block-four" class="block-four">


<div class="derecha-2">

<div class="floaty">

		<h1 class="titulo wid">TIME SERIES DATA</h1>

<div class="boton-final">
<button name="button" onclick="document.getElementById('descargar').click()" style="cursor: pointer;">DOWNLOAD FILE</button>
<button name="button" onclick="graficas()"style="cursor: pointer; padding-right: 10PX;">DOWNLOAD FIGURES</button>
<a id="descargar" href="file.doc" style="display:none"></a>
</div></div>
<div id="procesandoGrathic" class="modal">



  <!-- Modal content -->

  <div class="modal-content-animation">

    <h3>Waiting for the grathic</h3>

                               <img src="<?php echo 'http://'.$_SERVER["HTTP_HOST"].'/assets/img/loadin_gif.gif'?>" alt="this slowpoke moves" />

  </div>



</div>


	<div class="container-top flow" >
		<div class="resumen" id="resumen">
		</div>
		<div class="grafic one">
			<h4>TemperaturesGas</h4>
			<canvas class="canvas-grande" id="TemperaturesGas"></canvas></div>
		<div class="grafic one">
			<h4>TemperaturesParticles</h4><canvas class="canvas-grande" id="TemperaturesParticles"></canvas></div>
		<div class="grafic one">
			<h4>MassFlows</h4>
			<canvas class="canvas-grande" id="MassFlows"></canvas></div>
		<div class="grafic one">
			<h4>VolumetricFlowRate</h4>
			<canvas class="canvas-grande" id="VolumetricFlowRate"></canvas></div>
		<div class="grafic one">
			<h4>EvapRate</h4>
			<canvas class="canvas-grande" id="EvapRate"></canvas></div>
		<div class="grafic one">
			<h4>Humidity</h4>
			<canvas class="canvas-grande" id="Humidity"></canvas></div>
		<div class="grafic one">
			<h4>Balances</h4>
			<canvas class="canvas-grande" id="Balances"></canvas></div>
		<div class="grafic one">
			<h4>derLargeParticles</h4>
			<canvas class="canvas-grande" id="derLargeParticles"></canvas></div>

<div id="oculto">
	</div>



</div>



<div>
	<a onclick="volver1()" class="pre" href="#"><img  src="<?php echo 'http://'.$_SERVER["HTTP_HOST"].'/assets/img/pre.png'?>" alt="pre"> </a>
</div>

</section>



</body>
</html>
