
<!DOCTYPE html>
<html lang="en" >
  <!-- begin::Head -->
  <head>
    <meta charset="utf-8" />
    <meta name="description" content="Latest updates and statistic charts">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--begin::Web font -->
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js"></script>
    <script>
          WebFont.load({
            google: {"families":["Poppins:300,400,500,600,700","Roboto:300,400,500,600,700","Asap+Condensed:500"]},
            active: function() {
                sessionStorage.fonts = true;
            }
          });
    </script>
    <!--end::Web font -->
        <!--begin::Base Styles -->
        <!--begin::Page Vendors -->
    <link href="<?php echo 'http://'.$_SERVER["HTTP_HOST"];?>/assets/vendors/custom/fullcalendar/fullcalendar.bundle.css" rel="stylesheet" type="text/css" />
    <!--end::Page Vendors -->
    <link href="<?php echo 'http://'.$_SERVER["HTTP_HOST"];?>/assets/vendors/base/vendors.bundle.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo 'http://'.$_SERVER["HTTP_HOST"];?>/assets/demo/demo10/base/style.bundle.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo 'http://'.$_SERVER["HTTP_HOST"];?>/assets/css/custom.css" rel="stylesheet" type="text/css" />
    <!--end::Base Styles -->
    <link rel="shortcut icon" href="<?php echo 'http://'.$_SERVER["HTTP_HOST"];?>/assets/demo10/demo/media/img/logo/favicon.ico" />
  </head>
  <!-- end::Head -->
    <!-- end::Body -->
  <body class="m-page--fluid m-page--loading-enabled m-page--loading m-header--fixed m-header--fixed-mobile m-footer--push m-aside--offcanvas-default" >
    <!-- begin::Page loader -->
    <div class="m-page-loader m-page-loader--base">
      <div class="m-blockui">
        <span>
          Please wait...
        </span>
        <span>
          <div class="m-loader m-loader--brand"></div>
        </span>
      </div>
    </div>
    <!-- end::Page Loader -->
      <!-- begin:: Page -->
    <div class="m-grid m-grid--hor m-grid--root m-page">
    <!-- begin::Body -->
      <div class="content-login">
        <div class="logo-login">
  <img alt="" src="<?php echo 'http://'.$_SERVER["HTTP_HOST"];?>/assets/img/logo.png" class="m-brand__logo-desktop"/>
</div>
<div class="form-login">
  <form action="<?php echo 'http://'.$_SERVER["HTTP_HOST"]?>/index.php/Login/login" method="POST">
    <div class="col-lg-12">
      <div class="input-group m-input-icon m-input-icon--left">
        <input type="text" class="form-control m-input" name="user" placeholder="Nombre de usuario" style="border-color: #b1b1b1;">
        <span class="m-input-icon__icon m-input-icon__icon--left">
             <span>
                 <i class="fla flaticon-user" style="font-size: 20px;"></i>
             </span>
        </span>
      </div>
      <div class="input-group m-input-icon m-input-icon--left">
        <input type="password" class="form-control m-input" name="password" placeholder="Contraseña" style="border-color: #b1b1b1; margin-top: 20px;">
        <span class="m-input-icon__icon m-input-icon__icon--left">
             <span>
                 <i class="fla flaticon-lock" style="margin-top: 28px; display: block; font-size: 24px;"></i>
             </span>
        </span>
      </div>
      <?php if ($incorrecto!=""): ?>
        <p style="color: red; margin-top: 11px; margin-bottom: 0;"><?php echo $incorrecto ?></p>
      <?php endif; ?>

      <div class="input-group m-input-icon m-input-icon--left">
        <button class="btn btn-primary boton-entrar-login">Entrar</button>
      </div>
   </div>
  </form>
</div>      </div>
      <!-- end::Body -->
            <!-- begin::Footer -->
      <footer class="m-grid__item m-footer ">
        <div class="m-container m-container--fluid m-container--full-height m-page__container">
          <div class="m-footer__wrapper">
            <div class="m-stack m-stack--flex-tablet-and-mobile m-stack--ver m-stack--desktop">
            </div>
          </div>
        </div>
      </footer>
      <!-- end::Footer -->
    </div>
    <!-- end:: Page -->
                  <!-- begin::Quick Sidebar -->

    <div id="m_scroll_top" class="m-scroll-top">
      <i class="la la-arrow-up"></i>
    </div>
      <!--begin::Base Scripts -->
    <script src="<?php echo 'http://'.$_SERVER["HTTP_HOST"];?>/assets/vendors/base/vendors.bundle.js" type="text/javascript"></script>
    <script src="<?php echo 'http://'.$_SERVER["HTTP_HOST"];?>/assets/demo/demo10/base/scripts.bundle.js" type="text/javascript"></script>
    <!--end::Base Scripts -->
        <!--begin::Page Vendors -->
    <script src="<?php echo 'http://'.$_SERVER["HTTP_HOST"];?>/assets/vendors/custom/fullcalendar/fullcalendar.bundle.js" type="text/javascript"></script>
    <!--end::Page Vendors -->
        <!--begin::Page Snippets -->
    <script src="<?php echo 'http://'.$_SERVER["HTTP_HOST"];?>/assets/app/js/dashboard.js" type="text/javascript"></script>
    <!--end::Page Snippets -->
        <!-- begin::Page Loader -->
        <script src="<?php echo 'http://'.$_SERVER["HTTP_HOST"];?>/assets/js/custom.js" type="text/javascript"></script>
        <script>

            $(window).on('load', function() {
                $('body').removeClass('m-page--loading');
            });
    </script>

    <!-- end::Page Loader -->
  </body>
  <!-- end::Body -->
</html>
